import fs from 'node:fs';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

// Fecha de compilación de ESTE archivo (git archive fija el mtime al commit;
// el zip y Expand-Archive lo conservan). Se pinta en una esquina del panel
// para poder ver de un vistazo qué versión está corriendo la tienda.
let VERSION = '';
try {
  const st = fs.statSync(fileURLToPath(import.meta.url));
  const d = st.mtime;
  VERSION = `v ${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
} catch { /* sin versión */ }

// Panel de escritorio del bot: un mini servidor HTTP SOLO en 127.0.0.1 con
// una página de botones grandes para las acciones de cada día (imprimir la
// lista de llegada, refrescar promociones, análisis de ahorro…). Los botones
// despachan EXACTAMENTE los mismos comandos que se escribirían en Telegram
// (mismo código, mismas guardas, misma confirmación de escritura) y el
// resultado llega por Telegram como siempre — el panel es un mando a
// distancia con estado, no un segundo canal de salida. Sin dependencias:
// node:http y una página autocontenida. panel.cmd lo abre en el navegador.

export function startPanel(config, logger, hooks) {
  const port = Number(config.panel?.port) || 8765;
  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
        // no-store: que el navegador NUNCA sirva una página vieja de caché
        // después de actualizar el bot.
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
        res.end(renderPage());
        return;
      }
      if (req.method === 'GET' && req.url === '/status') {
        const status = await hooks.status();
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify(status));
        return;
      }
      if (req.method === 'GET' && req.url.startsWith('/chat')) {
        const since = new URL(req.url, 'http://x').searchParams.get('since') || '0';
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify(hooks.chat ? hooks.chat(since) : { seq: 0, messages: [] }));
        return;
      }
      if (req.method === 'POST' && req.url === '/callback') {
        const body = await readBody(req);
        let data = '';
        try { data = String(JSON.parse(body || '{}').data || '').trim(); } catch { /* json roto */ }
        if (!data) { res.writeHead(400, { 'content-type': 'application/json' }); res.end('{"ok":false}'); return; }
        logger?.info('panel callback', { data });
        const toast = hooks.callback ? await hooks.callback(data) : '';
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ ok: true, toast }));
        return;
      }
      if (req.method === 'GET' && req.url.startsWith('/file/')) {
        // El id llega con ?s=<seq> para saltar la caché del navegador.
        const filePath = hooks.file ? hooks.file(req.url.slice(6).split('?')[0]) : null;
        if (!filePath) { res.writeHead(404); res.end(); return; }
        const low = filePath.toLowerCase();
        const tipo = low.endsWith('.jpg') || low.endsWith('.jpeg') ? 'image/jpeg'
          : low.endsWith('.png') ? 'image/png'
          : low.endsWith('.csv') ? 'text/csv; charset=utf-8'
          : 'text/plain; charset=utf-8';
        res.writeHead(200, { 'content-type': tipo });
        fs.createReadStream(filePath).pipe(res);
        return;
      }
      if (req.method === 'GET' && req.url === '/comandos') {
        res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
        res.end(hooks.commandList());
        return;
      }
      if (req.method === 'POST' && req.url === '/run') {
        const body = await readBody(req);
        let cmd = '';
        try { cmd = String(JSON.parse(body || '{}').cmd || '').trim(); } catch { /* json roto */ }
        if (!cmd) { res.writeHead(400, { 'content-type': 'application/json' }); res.end('{"ok":false,"error":"cmd vacio"}'); return; }
        logger?.info('panel command', { cmd });
        // No se espera al resultado (una impresión o un análisis tardan
        // minutos): se despacha y la respuesta llega por Telegram.
        hooks.dispatch(cmd).catch((error) => logger?.error('panel dispatch failed', { cmd, error: error.message }));
        res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ ok: true }));
        return;
      }
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('no existe');
    } catch (error) {
      logger?.error('panel request failed', { url: req.url, error: error.message });
      try { res.writeHead(500, { 'content-type': 'application/json' }); res.end('{"ok":false}'); } catch { /* ya cerrado */ }
    }
  });
  server.on('error', (error) => logger?.warn('panel server error', { error: error.message }));
  // SOLO loopback: el panel no lleva autenticación, no debe salir del PC.
  server.listen(port, '127.0.0.1', () => logger?.info('panel listening', { url: `http://127.0.0.1:${port}`, version: VERSION }));
  return server;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => { data += chunk; if (data.length > 65536) { reject(new Error('body demasiado grande')); req.destroy(); } });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function renderPage() {
  return `<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>JARVIS</title>
<style>
  * { box-sizing: border-box; }
  html, body { height: 100%; }
  body {
    margin: 0; background: #111927; color: #d7e1ea;
    font-family: "Segoe UI", "Microsoft YaHei", sans-serif;
    display: flex; flex-direction: column;
    background-image: radial-gradient(ellipse 70% 45% at 50% 38%, rgba(56,189,248,.12), transparent 70%);
  }
  header {
    display: flex; justify-content: space-between; align-items: center;
    padding: 18px 26px; font-size: 12px; letter-spacing: .18em; color: #76879a;
  }
  #logo { color: #7dd3fc; font-weight: 600; }
  #estado { display: flex; gap: 18px; align-items: center; }
  #btnCajon {
    background: none; border: 1px solid rgba(125,211,252,.3); color: #97c9e3;
    border-radius: 999px; padding: 5px 16px; font-size: 11px; letter-spacing: .25em;
    cursor: pointer; font-family: inherit;
  }
  #btnCajon:hover { border-color: rgba(125,211,252,.65); color: #d5ecf8; }
  #punto { width: 8px; height: 8px; border-radius: 50%; background: #22c55e; display: inline-block; margin-right: 7px; vertical-align: 1px; animation: latido 2.4s ease-in-out infinite; }
  #punto.rojo { background: #ef4444; animation: none; }
  @keyframes latido { 0%,100% { opacity: 1; } 50% { opacity: .35; } }
  main { flex: 1; display: flex; flex-direction: column; align-items: center; padding: 0 24px 24px; min-height: 0; }
  #saludo { font-size: 13px; letter-spacing: .3em; color: #5f7184; margin-bottom: 26px; text-transform: uppercase; }
  #linea {
    width: min(800px, 94vw); display: flex; align-items: center; gap: 14px;
    border-bottom: 1px solid rgba(125,211,252,.25); padding: 6px 4px 12px;
    transition: border-color .25s;
  }
  #linea:focus-within { border-color: rgba(125,211,252,.75); }
  #linea::before { content: "›"; color: #38bdf8; font-size: 26px; line-height: 1; }
  #libre {
    flex: 1; background: none; border: none; outline: none; color: #e6eef4;
    font-size: 20px; font-weight: 300; letter-spacing: .02em; caret-color: #38bdf8;
  }
  #libre::placeholder { color: #53657a; }
  #pills { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 6px; }
  .pill {
    background: none; border: 1px solid rgba(200,211,220,.22); color: #b6c4d1;
    border-radius: 999px; padding: 9px 18px; font-size: 14px; cursor: pointer;
    transition: all .2s;
  }
  .pill:hover { border-color: rgba(125,211,252,.6); color: #cfe9f7; }
  .pill:active { transform: scale(.97); }
  #reloj { margin-top: 2vh; font-size: 76px; font-weight: 200; letter-spacing: .06em; color: #eef5fa; line-height: 1; font-variant-numeric: tabular-nums; }
  #reloj span.seg { font-size: 26px; color: #38bdf8; font-weight: 300; margin-left: 6px; }
  #fecha { margin: 12px 0 40px; font-size: 13px; letter-spacing: .28em; color: #76879a; text-transform: uppercase; }
  #tarjetas { margin-top: 22px; display: grid; gap: 10px; grid-template-columns: 1fr; }
  #cajonTeclado { display: none; }
  .tarjeta { border: 1px solid rgba(200,211,220,.16); background: rgba(148,180,205,.05); border-radius: 12px; padding: 14px 16px; min-height: 88px; }
  .tarjeta .titulo { font-size: 11px; letter-spacing: .25em; color: #5f7184; margin-bottom: 9px; }
  .tarjeta .dato { font-size: 14px; color: #aebdcb; line-height: 1.65; }
  .tarjeta .dato b { color: #cfe9f7; font-weight: 500; }
  .tarjeta .dato .hora { color: #5f7184; font-size: 12px; margin-right: 8px; font-variant-numeric: tabular-nums; }
  #charla {
    /* flex 1: el chat se estira hasta la línea de comando, pegada abajo */
    flex: 1 1 0; min-height: 0; width: min(800px, 94vw); overflow-y: auto;
    margin: 8px 0 20px; scrollbar-width: thin;
    scrollbar-color: rgba(125,211,252,.2) transparent;
    -webkit-mask-image: linear-gradient(to bottom, transparent, black 24px);
  }
  .msg { display: flex; margin: 13px 0; }
  .msg.mia { justify-content: flex-end; }
  .burbuja {
    max-width: 84%;
    font-size: 15.5px; line-height: 1.65; white-space: pre-wrap; word-break: break-word;
    color: #b4c2cf;
  }
  .mia .burbuja { color: #cfe9f7; text-align: right; }
  .burbuja .meta { display: block; font-size: 10.5px; color: #53657a; letter-spacing: .14em; margin-top: 4px; }
  .chipTeclado, .chipLeer {
    display: inline-flex; align-items: center; margin: 8px 8px 0 0;
    background: none; border: 1px solid rgba(56,189,248,.4); color: #97c9e3;
    border-radius: 999px; padding: 4px 14px; font-size: 12px; cursor: pointer; letter-spacing: .12em;
  }
  .chipTeclado:hover, .chipLeer:hover { border-color: rgba(125,211,252,.6); color: #d5ecf8; }
  /* --- cajón lateral: donde viven los teclados interactivos --- */
  #cajon {
    position: fixed; top: 0; left: 0; bottom: 0; width: min(400px, 88vw);
    background: rgba(20,29,41,.97); border-right: 1px solid rgba(125,211,252,.22);
    box-shadow: 18px 0 50px rgba(0,0,0,.45);
    transform: translateX(-102%); transition: transform .28s ease;
    display: flex; flex-direction: column; z-index: 30;
  }
  #cajon.abierto { transform: translateX(0); }
  #cajon .cab {
    display: flex; justify-content: space-between; align-items: center;
    padding: 18px 20px 12px; font-size: 11px; letter-spacing: .3em; color: #76879a;
  }
  #cajon .cab b { color: #7dd3fc; font-weight: 600; }
  #cajon .cab button {
    background: none; border: none; color: #76879a; font-size: 18px; cursor: pointer; padding: 2px 6px;
  }
  #cajon .cab button:hover { color: #cfe9f7; }
  #cajon .cuerpo { flex: 1; overflow-y: auto; padding: 4px 20px 24px; scrollbar-width: thin; scrollbar-color: rgba(125,211,252,.2) transparent; }
  #cajon .texto { font-size: 13.5px; color: #aebdcb; line-height: 1.6; white-space: pre-wrap; margin-bottom: 14px; }
  #cajon img { max-width: 100%; border-radius: 10px; border: 1px solid rgba(200,211,220,.12); margin-bottom: 14px; display: block; }
  #cajon .filaB { display: flex; gap: 8px; margin-bottom: 8px; }
  #cajon .filaB button {
    flex: 1; background: rgba(56,189,248,.06); border: 1px solid rgba(56,189,248,.35); color: #b9e2f6;
    border-radius: 10px; padding: 13px 10px; font-size: 15px; cursor: pointer; transition: all .15s;
  }
  #cajon .filaB button:hover { background: rgba(56,189,248,.16); color: #e2f3fc; }
  #cajon .filaB button:active { transform: scale(.97); }
  #lector {
    position: fixed; top: 0; right: 0; bottom: 0; width: min(620px, 94vw);
    background: rgba(20,29,41,.97); border-left: 1px solid rgba(125,211,252,.22);
    box-shadow: -18px 0 50px rgba(0,0,0,.45);
    transform: translateX(102%); transition: transform .28s ease;
    display: flex; flex-direction: column; z-index: 30;
  }
  #lector.abierto { transform: translateX(0); }
  #lector .cab {
    display: flex; justify-content: space-between; align-items: center; gap: 12px;
    padding: 18px 20px 12px; font-size: 11px; letter-spacing: .2em; color: #76879a;
  }
  #lector .cab b { color: #7dd3fc; font-weight: 600; white-space: nowrap; }
  #lectorFoto { padding: 0 20px; }
  #lectorFoto img { max-width: 100%; border-radius: 10px; border: 1px solid rgba(200,211,220,.12); }
  #lector .cab span.titulo { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; text-align: right; }
  #lector .cab button { background: none; border: none; color: #76879a; font-size: 18px; cursor: pointer; padding: 2px 6px; }
  #lector .cab button:hover { color: #cfe9f7; }
  #lector pre {
    flex: 1; overflow: auto; margin: 0; padding: 6px 20px 24px;
    font-family: Consolas, "Courier New", monospace; font-size: 13px; line-height: 1.6;
    color: #bdcad7; white-space: pre-wrap; word-break: break-word;
    scrollbar-width: thin; scrollbar-color: rgba(125,211,252,.2) transparent;
  }
  #aviso {
    position: fixed; left: 50%; bottom: 34px; transform: translateX(-50%);
    color: #7dd3fc; font-size: 13px; letter-spacing: .12em;
    opacity: 0; transition: opacity .35s; pointer-events: none;
  }
  #aviso.visible { opacity: .9; }
  #ver { position: fixed; right: 16px; bottom: 10px; font-size: 10px; letter-spacing: .12em; color: rgba(125,211,252,.45); pointer-events: none; }
</style>
</head>
<body>
<header>
  <span id="logo">J A R V I S</span>
  <span id="estado"><button id="btnCajon" onclick="abrirCajonInicio()">操 作 台</button><span><span id="punto"></span><span id="txtEstado">连接中</span></span></span>
</header>
<main>
  <div id="reloj">--:--</div>
  <div id="fecha">&nbsp;</div>
  <div id="saludo">需要我做什么</div>
  <div id="charla"></div>
  <div id="linea">
    <input id="libre" autofocus>
  </div>
</main>
<div id="lector">
  <div class="cab"><b>阅 读</b><span class="titulo" id="lectorTitulo"></span><button onclick="cerrarLector()" title="关闭">✕</button></div>
  <div id="lectorFoto"></div>
  <pre id="lectorTexto"></pre>
</div>
<div id="cajon">
  <div class="cab"><span><b>操 作 台</b></span><button onclick="cerrarCajon()" title="关闭">✕</button></div>
  <div class="cuerpo">
    <div id="cajonInicio">
      <div id="pills">
        <button class="pill" onclick="run('/llegada')">打印今天清单</button>
        <button class="pill" onclick="run('/promociones')">刷新促销</button>
        <button class="pill" onclick="run('/ahorro_pedido')">PDA 省钱分析</button>
        <button class="pill" onclick="run('/pedido')">叫货提醒</button>
        <button class="pill" onclick="run('/carne')">肉类盘点</button>
        <button class="pill" onclick="run('/ahorro')">总体省钱策略</button>
      </div>
      <div id="tarjetas">
        <div class="tarjeta">
          <div class="titulo">今日</div>
          <div class="dato" id="tHoy">—</div>
        </div>
        <div class="tarjeta">
          <div class="titulo">促销</div>
          <div class="dato" id="tPromo">—</div>
        </div>
        <div class="tarjeta ancha">
          <div class="titulo">最近动态</div>
          <div class="dato" id="tActividad">—</div>
        </div>
      </div>
    </div>
    <div id="cajonTeclado">
      <div class="texto" id="cajonTexto"></div>
      <div id="cajonFoto"></div>
      <div id="cajonBotones"></div>
    </div>
  </div>
</div>
<div id="aviso"></div>
<div id="ver">${VERSION}</div>
<script>
const libre = document.getElementById('libre');
libre.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && libre.value.trim()) { run(libre.value.trim()); libre.value = ''; }
});

// --- chat sincronizado con Telegram: el bot guarda la transcripción y el
// panel la va pidiendo (solo lo nuevo, por seq). Lo tecleado aquí llega a
// Telegram como eco "🖥 …", y lo del móvil aparece aquí solo.
let chatSeq = 0;
const filas = new Map(); // id → elemento .msg (para actualizar botones editados en sitio)
// El panel es sobrio: los emojis de los mensajes (pensados para Telegram)
// se filtran solo en la VISUALIZACION; en Telegram y en el registro siguen.
function sinEmoji(s) {
  return String(s || '').replace(/[\\u{1F000}-\\u{1FAFF}\\u{2600}-\\u{27BF}\\u{2B00}-\\u{2BFF}\\u{2300}-\\u{23FF}\\u{FE0F}\\u{200D}]/gu, '').replace(/  +/g, ' ').replace(/^ +/gm, '').trim();
}
function pintarBurbuja(m) {
  const b = document.createElement('div');
  b.className = 'burbuja';
  const cuerpo = document.createElement('div');
  const completo = sinEmoji(m.text);
  const esLargo = completo.length > 380 || completo.split('\\n').length > 8;
  if (esLargo) {
    // Los informes largos no llenan el chat: recorte + "展开" en el lector.
    const lineas = completo.split('\\n').slice(0, 4).join('\\n');
    cuerpo.textContent = (lineas.length > 380 ? lineas.slice(0, 380) : lineas) + ' …';
  } else {
    cuerpo.textContent = completo;
  }
  b.appendChild(cuerpo);
  const chips = document.createElement('div');
  if (esLargo) {
    const chip = document.createElement('span');
    chip.className = 'chipLeer';
    chip.textContent = '展开阅读';
    chip.onclick = () => abrirLector(sinEmoji(m.text).split('\\n')[0].slice(0, 40), sinEmoji(m.text));
    chips.appendChild(chip);
  }
  if (m.doc) {
    const chip = document.createElement('span');
    chip.className = 'chipLeer';
    chip.textContent = '打开文件';
    chip.onclick = async () => {
      try {
        const r = await fetch('/file/' + m.id);
        if (!r.ok) { aviso('文件已不在（可能重启后被清理）'); return; }
        abrirLector(sinEmoji(m.text).slice(0, 40), await r.text());
      } catch { aviso('连不上 BOT'); }
    };
    chips.appendChild(chip);
  }
  if (m.photo && !(m.buttons && m.buttons.length)) {
    // Las capturas no se incrustan en el chat: se abren en el lector. Las de
    // tarjetas con botones ya se ven en el cajón de operaciones.
    const chip = document.createElement('span');
    chip.className = 'chipLeer';
    chip.textContent = '查看截图';
    chip.onclick = () => abrirLector(sinEmoji(m.text).slice(0, 40), '', '/file/' + m.id + '?s=' + m.seq);
    chips.appendChild(chip);
  }
  if (m.buttons && m.buttons.length) {
    // Los teclados NO se pintan en la burbuja: viven en el cajón lateral.
    const chip = document.createElement('span');
    chip.className = 'chipTeclado';
    chip.textContent = '操作台';
    chip.onclick = () => abrirCajon(m.id);
    chips.appendChild(chip);
  }
  if (chips.children.length) b.appendChild(chips);
  const meta = document.createElement('span');
  meta.className = 'meta';
  const t = new Date(m.at);
  meta.textContent = (m.from === 'bot' ? 'JARVIS' : m.from === 'panel' ? '面板' : '你') + ' · ' + String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0');
  b.appendChild(meta);
  return b;
}
// --- lector (cajón derecho para contenido largo) ---------------------------
function abrirLector(titulo, texto, fotoUrl) {
  document.getElementById('lectorTitulo').textContent = titulo || '';
  document.getElementById('lectorTexto').textContent = texto || '';
  const foto = document.getElementById('lectorFoto');
  foto.innerHTML = '';
  if (fotoUrl) {
    const img = document.createElement('img');
    img.src = fotoUrl;
    foto.appendChild(img);
  }
  document.getElementById('lector').classList.add('abierto');
}
function cerrarLector() { document.getElementById('lector').classList.remove('abierto'); }

// --- cajón lateral -------------------------------------------------------
const datos = new Map();      // id → último estado del mensaje (para re-render)
const cajonCerrados = new Set(); // teclados que el usuario cerró a mano
let cajonId = null;
function renderCajon(m) {
  document.getElementById('cajonInicio').style.display = 'none';
  document.getElementById('cajonTeclado').style.display = 'block';
  document.getElementById('cajonTexto').textContent = sinEmoji(m.text);
  const foto = document.getElementById('cajonFoto');
  foto.innerHTML = '';
  if (m.photo) {
    const img = document.createElement('img');
    img.src = '/file/' + m.id + '?s=' + m.seq;
    foto.appendChild(img);
  }
  const zona = document.getElementById('cajonBotones');
  zona.innerHTML = '';
  for (const fila of m.buttons || []) {
    const f = document.createElement('div');
    f.className = 'filaB';
    for (const bot of fila) {
      const btn = document.createElement('button');
      btn.textContent = sinEmoji(bot.t) || bot.t;
      btn.onclick = () => pulsar(bot.d);
      f.appendChild(btn);
    }
    zona.appendChild(f);
  }
  document.getElementById('cajon').classList.add('abierto');
}
function abrirCajon(id) {
  const m = datos.get(id);
  if (!m) return;
  cajonCerrados.delete(id);
  cajonId = id;
  renderCajon(m);
}
function cerrarCajon() {
  if (cajonId != null) cajonCerrados.add(cajonId);
  document.getElementById('cajon').classList.remove('abierto');
}
// Vista por defecto del cajón: los accesos rápidos y las tarjetas de estado
// (antes vivían en el centro de la página; el chat necesitaba el sitio).
function abrirCajonInicio() {
  cajonId = null;
  document.getElementById('cajonTeclado').style.display = 'none';
  document.getElementById('cajonInicio').style.display = 'block';
  document.getElementById('cajon').classList.add('abierto');
}

async function pulsar(data) {
  try {
    const r = await (await fetch('/callback', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ data }) })).json();
    if (r.toast) aviso(r.toast);
    setTimeout(pollChat, 300);
  } catch { aviso('连不上 BOT'); }
}
async function pollChat() {
  try {
    const r = await (await fetch('/chat?since=' + chatSeq)).json();
    if (r.messages && r.messages.length) {
      const caja = document.getElementById('charla');
      const pegado = caja.scrollHeight - caja.scrollTop - caja.clientHeight < 60;
      let nuevos = false;
      for (const m of r.messages) {
        chatSeq = Math.max(chatSeq, m.seq);
        if (m.buttons && m.buttons.length) {
          datos.set(m.id, m);
          if (!cajonCerrados.has(m.id) && (cajonId == null || m.seq >= (datos.get(cajonId)?.seq || 0) || m.id === cajonId)) {
            cajonId = m.id;
            renderCajon(m);
          } else if (m.id === cajonId) {
            renderCajon(m);
          }
        }
        const previa = filas.get(m.id);
        if (previa) {
          // Entrada editada (teclado del recuento, etc.): refrescar en sitio.
          const vieja = previa.querySelector('.burbuja');
          previa.replaceChild(pintarBurbuja(m), vieja);
          continue;
        }
        const fila = document.createElement('div');
        fila.className = 'msg' + (m.from === 'bot' ? '' : ' mia');
        fila.appendChild(pintarBurbuja(m));
        caja.appendChild(fila);
        filas.set(m.id, fila);
        nuevos = true;
      }
      while (caja.children.length > 120) {
        const primero = caja.firstChild;
        for (const [id, el] of filas) if (el === primero) filas.delete(id);
        caja.removeChild(primero);
      }
      caja.classList.add('con');
      if (pegado && nuevos) caja.scrollTop = caja.scrollHeight;
    }
  } catch { /* bot apagado: el punto rojo ya lo dice */ }
}
pollChat();
setInterval(pollChat, 2500);
async function run(cmd) {
  try {
    const r = await fetch('/run', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ cmd }) });
    aviso(r.ok ? '已收到' : '发送失败');
    setTimeout(pollChat, 350);
  } catch { aviso('连不上 BOT'); }
}
function aviso(txt) {
  const el = document.getElementById('aviso');
  el.textContent = txt;
  el.classList.add('visible');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('visible'), 2400);
}
async function refrescar() {
  const punto = document.getElementById('punto');
  const txt = document.getElementById('txtEstado');
  try {
    const s = await (await fetch('/status')).json();
    punto.classList.remove('rojo');
    const partes = ['在线 ' + s.uptime];
    partes.push('促销 ' + (s.promoCsv || '无'));
    partes.push(s.autoRanToday ? '晨务 已办' : '晨务 —');
    const off = [];
    if (!s.webOrder) off.push('网页');
    if (!s.desktop) off.push('桌面');
    if (!s.llm) off.push('AI');
    if (off.length) partes.push(off.join('/') + ' 关');
    txt.textContent = partes.join('　·　');
    pintarTarjetas(s);
  } catch {
    punto.classList.add('rojo');
    txt.textContent = '离线 — 黑窗口开着吗？';
  }
}
function tic() {
  const d = new Date();
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  document.getElementById('reloj').innerHTML = hh + ':' + mm + '<span class="seg">' + ss + '</span>';
  const dias = ['周日','周一','周二','周三','周四','周五','周六'];
  document.getElementById('fecha').textContent = d.getFullYear() + ' / ' + String(d.getMonth() + 1).padStart(2, '0') + ' / ' + String(d.getDate()).padStart(2, '0') + '　' + dias[d.getDay()];
  const h = d.getHours();
  document.getElementById('saludo').textContent = (h < 6 ? '夜深了' : h < 12 ? '早上好' : h < 20 ? '下午好' : '晚上好') + '，需要我做什么';
}
tic();
setInterval(tic, 1000);
function pintarTarjetas(s) {
  document.getElementById('tHoy').innerHTML =
    '预计到货 <b>' + (s.arrivingToday ?? 0) + '</b> 单<br>晨务 ' + (s.autoRanToday ? '<b>已完成</b>' : '还没跑');
  if (s.promoStats) {
    document.getElementById('tPromo').innerHTML =
      '<b>' + s.promoStats.promos + '</b> 个活动 · <b>' + s.promoStats.items + '</b> 个商品<br>今明到期 <b>' + s.promoStats.endingSoon + '</b> 个' + (s.promoCsv ? '<br>数据：' + s.promoCsv : '');
  } else {
    document.getElementById('tPromo').textContent = '还没有促销数据，点「刷新促销」';
  }
  const act = (s.activity || []).slice(0, 4).map((a) => {
    const t = new Date(a.at);
    const hh = String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0');
    return '<span class="hora">' + hh + '</span>' + escapar(a.text);
  });
  document.getElementById('tActividad').innerHTML = act.length ? act.join('<br>') : '还没有动静';
}
function escapar(x) { const d = document.createElement('div'); d.textContent = x; return d.innerHTML; }
refrescar();
setInterval(refrescar, 15000);
</script>
</body>
</html>`;
}
